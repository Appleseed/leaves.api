Important restrictions:
    - Dependencies loading not supported.
    - Result data not supported - direct link change by ref.
    - Timing not supported.

TODO:
- sourceId: 'fb' for video_src

later:
- safe html
