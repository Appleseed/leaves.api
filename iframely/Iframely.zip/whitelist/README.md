If you put your own whitelist json file here, Iframely will use it to covere domains through oEmbed, Open Graph and Twitter Cards.

The file name is expected to be of "iframely-*.json" pattern. Lastest filename uploaded to this directory is used. 

Please, follow this [file format](http://iframely.com/qa/format).

By default, the package uses Iframely's whitelist with over 1600 domains. We do manual QA every day, so it might be wise of you to rely on us for whitelisting.