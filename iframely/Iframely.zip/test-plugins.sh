node ./modules/tests-ui/tester $1
