module.exports = {

    getMeta: function(meta) {
        return {
            title: 'TITLE FROM CUSTOM-PLUGIN'
        };
    },

    lowestPriority: true
};
