module.exports = {

    getLink: function(test_data2) {
        return {
            href: 'http://test.com',
            type: 'text/html'
        };
    },

    tests: {
        noTest: true
    }
};