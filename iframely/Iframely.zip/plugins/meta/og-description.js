module.exports = {

    getMeta: function(og) {

        return {
            description: og.description
        };
    }
};