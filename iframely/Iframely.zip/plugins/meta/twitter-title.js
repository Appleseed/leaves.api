module.exports = {

    getMeta: function(twitter) {

        return {
            title: twitter.title
        };
    }
};
