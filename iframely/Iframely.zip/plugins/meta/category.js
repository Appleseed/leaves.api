module.exports = {

    getMeta: function(meta) {
        return {
            category: meta.category
        };
    }
};