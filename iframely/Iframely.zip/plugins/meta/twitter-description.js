module.exports = {

    getMeta: function(twitter) {

        return {
            description: twitter.description
        }
    }
};