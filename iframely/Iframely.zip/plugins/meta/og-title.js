module.exports = {

    getMeta: function(og) {

        return {
            title: og.title
        };
    }
};
