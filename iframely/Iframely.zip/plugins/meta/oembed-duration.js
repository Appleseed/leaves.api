module.exports = {

    getMeta: function(oembed) {
        return {
            duration: oembed.duration
        }
    }
};