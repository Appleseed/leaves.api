module.exports = {

    getMeta: function(oembed) {
        return {
            description: oembed.description
        }
    }
};