module.exports = {

    getMeta: function(og) {

        return {
            site: og.site_name
        };
    }
};