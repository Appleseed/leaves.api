module.exports = {

    getData: function(oembedError, cb) {

        return cb({responseError: oembedError});

    }
};